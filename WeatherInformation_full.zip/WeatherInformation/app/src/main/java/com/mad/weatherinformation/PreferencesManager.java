package com.mad.weatherinformation;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferencesManager {
    private static final String PREF_LAST_SEARCHED_CITY = "last_searched_city";

    public static void saveLastSearchedCity(Context context, String city) {
        SharedPreferences.Editor editor = context.getSharedPreferences("WeatherApp", Context.MODE_PRIVATE).edit();
        editor.putString(PREF_LAST_SEARCHED_CITY, city);
        editor.apply();
    }

    public static String getLastSearchedCity(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("WeatherApp", Context.MODE_PRIVATE);
        return prefs.getString(PREF_LAST_SEARCHED_CITY, "");
    }
}
